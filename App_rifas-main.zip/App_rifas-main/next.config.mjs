/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: false,
  /* config options here */
};

export default nextConfig;