// Backup da home antiga - foi substituída por listagem de rifas
